# Original Project Proposal

## Project title
**Galvanic Skin Response (GSR) Stress Monitor: Investigating the Sampling-Rate and Power Trade-off**

## 1. Background and motivation
Electrodermal activity (EDA) is the change in the skin's electrical conductance associated with sweat-gland activity. Sweat-gland activity is controlled by the sympathetic branch of the autonomic nervous system. EDA is therefore commonly used in research as one physiological signal related to arousal. However, EDA is not a direct or unique measurement of stress: movement, temperature, electrode placement, and individual differences also affect the signal.

This project proposes a low-cost ESP32-based system that measures a skin-resistance voltage divider and records EDA-related measurements for later analysis.

## 2. Problem statement and research question
A higher sampling rate produces more measurements, but it can increase data volume and may increase energy use depending on the firmware and power-management strategy. The project investigates:

**What skin-conductance sampling rate provides sufficient detection of a task-related EDA response while minimizing power consumption?**

## 3. Aim
To design, implement, and evaluate an ESP32-based EDA monitor and experimentally compare sampling rates of 1, 2, 4, 8, and 16 Hz.

## 4. Objectives
1. Design a current-limited EDA voltage-divider circuit.
2. Configure the ESP32 ADC and use calibrated millivolt readings.
3. Convert voltage measurements into estimated skin resistance and conductance.
4. Implement configurable sampling rates and serial CSV logging.
5. Simulate the signal input in Wokwi using a potentiometer as an analog emulator.
6. Conduct a repeatable rest–cognitive-task–recovery protocol, subject to instructor approval.
7. Compare response amplitude, timing, rest noise, sample count, and measured energy use across rates.
8. Document technical limitations and future improvements.

## 5. Proposed methodology

### Hardware and software
The physical prototype uses an ESP32 DevKit V1, two skin electrodes, and a 100 kΩ fixed resistor. The skin resistance and fixed resistor form a voltage divider connected to GPIO34 (ADC1). The ESP32 samples the voltage, applies light exponential smoothing, estimates resistance and conductance, and outputs CSV records through Serial Monitor.

Wokwi will be used to demonstrate the controller and data-logging logic. A potentiometer will emulate a variable analog input. This simulation does not reproduce actual skin physiology.

### Experimental protocol
After instructor approval and informed consent, record a quiet baseline, a timed Stroop color-word task, and a recovery period. Use consistent electrode placement, posture, and room conditions. Repeat the protocol at 1, 2, 4, 8, and 16 Hz in randomized order where practical. Record a subjective 0–10 task-stress rating as contextual information only. Use participant codes rather than names.

### Evaluation
Compare each rate with the 16 Hz reference. The planned decision rule is to select the lowest rate whose task peak differs by no more than 10% from the reference and whose response timing differs by no more than one second, while maintaining acceptable rest noise. Measure average current with a suitable power meter if available. If power cannot be measured, label any energy comparison as an estimate rather than a measured result.

## 6. Expected outcomes
The expected deliverables are a working ESP32 prototype or Wokwi simulation, documented circuit and code, timestamped CSV data, plots comparing sampling rates, a video demonstration, and a final report. The project is expected to identify a practical sampling rate for this specific prototype and protocol; it will not establish a universal physiological optimum.

## 7. Safety, ethics, and limitations
This is an educational prototype, not a medical device. Human measurements require instructor approval, voluntary informed consent, a battery-powered and electrically isolated setup, and the right to stop at any time. Do not connect electrodes to a person while the circuit is connected to unsafe equipment or mains-powered devices. Avoid collecting identifying information. EDA cannot independently diagnose stress.

## 8. Timeline
- Stage 1: Research and circuit design
- Stage 2: Wokwi simulation and firmware
- Stage 3: Physical assembly and calibration (if approved)
- Stage 4: Controlled data collection
- Stage 5: Analysis, plots, GitHub documentation, and video
