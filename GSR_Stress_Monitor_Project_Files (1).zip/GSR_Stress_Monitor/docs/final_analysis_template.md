# Final Project Analysis — Complete After Testing

> Replace every bracketed prompt with evidence from your actual build. Do not claim that a feature worked unless you tested it. If you only used Wokwi, state that clearly.

## 1. Summary
The project aimed to build an ESP32-based EDA monitor and investigate the sampling-rate / energy trade-off. The final implementation was [Wokwi simulation / physical prototype / both].

## 2. Goals achieved
- Voltage-divider signal acquisition: [evidence, photo or test]
- ESP32 ADC calibration: [known-resistor test and measured error]
- Conductance calculation: [example calculation / validation]
- Configurable sampling rates: [rates tested and serial-log evidence]
- CSV data logging: [file name and number of records]
- Wokwi simulation: [link and what it demonstrates]
- Video demonstration: [link]

## 3. Goals not achieved and reasons
[Explain any missing physical prototype, human data, power measurement, or incomplete rate tests. Distinguish technical limitations from time/resource limitations.]

## 4. Experimental results

| Sampling rate | Rest noise (SD, µS) | Peak change (µS) | Response latency (s) | Average current (mA) | Notes |
|---:|---:|---:|---:|---:|---|
| 1 Hz | [ ] | [ ] | [ ] | [ ] | [ ] |
| 2 Hz | [ ] | [ ] | [ ] | [ ] | [ ] |
| 4 Hz | [ ] | [ ] | [ ] | [ ] | [ ] |
| 8 Hz | [ ] | [ ] | [ ] | [ ] | [ ] |
| 16 Hz | [ ] | [ ] | [ ] | [ ] | Reference |

If current was not measured, write “Not measured” rather than inventing values.

## 5. Answer to the research question
Based on the collected data, the best tested rate was [X Hz] because [compare response amplitude, timing, noise, and measured power]. This conclusion applies only to this prototype and protocol.

## 6. Improvements with more time/resources
- Use a dedicated, isolated EDA analog front end with validated current limiting.
- Add battery operation and measure current in active and sleep modes.
- Add better motion-artifact detection and signal-quality checks.
- Collect a larger, ethically approved dataset.
- Use a more rigorous protocol and analyze tonic and phasic EDA components separately.
- Add wireless data export or an OLED display if useful.

## 7. Reflection
The most important engineering lesson was [ ]. The biggest limitation was [ ]. The project changed from the original proposal in the following ways: [ ].

## 8. Evidence checklist
- [ ] Clear photos of the complete prototype
- [ ] Circuit schematic / wiring diagram
- [ ] Source code and meaningful Git commits
- [ ] Raw CSV files (anonymized)
- [ ] Plots with labelled axes and event markers
- [ ] Actual power measurement or explicit statement that it was not measured
- [ ] 2–5 minute demonstration video
- [ ] GitHub README and this completed analysis
