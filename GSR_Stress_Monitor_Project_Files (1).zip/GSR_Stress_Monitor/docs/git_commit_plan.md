# Suggested Git commit sequence

Make commits as you complete each real stage. Do not create these commits retroactively if you have not done the work.

1. `Initial project structure and proposal`
2. `Add EDA circuit design and Wokwi diagram`
3. `Implement ESP32 ADC acquisition`
4. `Add conductance conversion and calibration`
5. `Add configurable sampling rates and CSV logging`
6. `Document experimental protocol and safety`
7. `Add measured data and analysis plots`
8. `Add prototype photos and demo video link`
9. `Finalize results and project reflection`

Useful commands:

```bash
git init
git add README.md docs/original_proposal.md
git commit -m "Initial project structure and proposal"
git add src/ diagram.json wokwi.toml
git commit -m "Add ESP32 firmware and Wokwi prototype"
git status
git log --oneline
```

Only commit files that are genuinely ready. Keep raw data anonymized and do not commit personal information.
